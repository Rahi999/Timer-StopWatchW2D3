import "./styles.css";
import Timer from "./components/Timer"


export default function App() {
  return (
    <div className="App">

    <Timer />
    </div>
  );
}
